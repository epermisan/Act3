function diAdeu() {
    setTimeout(function() {
      console.log("Adéu");
    }, 10000); // 10000 milisegundos = 10 segundos
  }
  diAdeu();
  